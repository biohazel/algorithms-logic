# include <iostream>
# include <locale>

int main() {
    setlocale(LC_ALL, "Portuguese");
    
    int option1, option2, option3, result;
    float n1, n2;

    

    if (option1 == 1) {
        result = n1 ** n2;
        for 

    }



}

